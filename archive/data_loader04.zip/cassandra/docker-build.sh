#!/bin/bash

docker rmi cassandra-whia:1.0
docker build -t cassandra-whia:1.0 . 
docker tag cassandra-whia:1.0 sleshkevich/test:cassandra-whia-1.0
docker push sleshkevich/test
docker images sleshkevich/test
